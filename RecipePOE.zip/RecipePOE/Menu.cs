﻿// See https://aka.ms/new-console-template for more information


using RecipePOE;
using System.Collections;
using System.Security.Cryptography.X509Certificates;

internal class Menu
{
    private Recipe recipe = null;


    internal void AddRecipe()
    {
        Console.WriteLine("Enter the Recipe Name:");
        string recipeName = Console.ReadLine();

        Console.WriteLine("\nEnter the number of ingredients:");

        //Error handling
        if (!int.TryParse(Console.ReadLine(), out int numIngredients) || numIngredients <= 0)
        {
            Console.WriteLine("\nInvalid number of ingredients. Please enter a positive integer.");
            
        }

        Recipe newRecipe = new Recipe(recipeName, numIngredients);

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"\nEnter the name of ingredient number {i + 1}:");
            string name = Console.ReadLine();

            Console.WriteLine($"\nEnter the quantity of ingredient number {i + 1}:");

            //Error handling
            if (!double.TryParse(Console.ReadLine(), out double quantity))
            {
                Console.WriteLine("\nInvalid quantity entered. Please enter a numeric value.");
                i--;  
                continue;
            }

            Console.WriteLine($"\nEnter the unit of measurement for ingredient number {i + 1}:");
            string unit = Console.ReadLine();

            newRecipe.Ingredients[i] = new Ingredient(name, quantity, unit);
        }

        Console.WriteLine("\nEnter the number of steps in the recipe:");

        //Error handling
        if (!int.TryParse(Console.ReadLine(), out int numSteps) || numSteps <= 0)
        {
            Console.WriteLine("\nInvalid number of steps. Please enter a positive integer.");
            
        }

        newRecipe.Steps = new string[numSteps];

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"\nEnter step {i + 1} of the recipe:");
            newRecipe.Steps[i] = Console.ReadLine();
        }

        // Save the newly created recipe
        this.recipe = newRecipe; 
    }

    public void Display()
    {
        if (recipe == null)
        {
            Console.WriteLine("\nNo recipe to display.");
            return;
        }

        Console.WriteLine($"\nRecipe for: {recipe.Name}");
        Console.WriteLine("Ingredients: ");
        foreach (var ingredient in recipe.Ingredients)
        {
            Console.WriteLine($"To make {recipe.Name} you will need {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < recipe.Steps.Length; i++)
        {
            Console.WriteLine($"Step {i + 1}: {recipe.Steps[i]}");
        }

        Console.WriteLine("\nWould you like to scale the recipe? (yes/no)");
        string answer = Console.ReadLine().Trim().ToLower();

        if (answer.Equals("yes"))
        {
            Console.WriteLine("\nBy what factor would you like to scale the recipe?");
            if (int.TryParse(Console.ReadLine(), out int scale) && scale > 0)
            {
                Console.WriteLine("\nScaled Ingredients:");
                foreach (var ingredient in recipe.Ingredients)
                {
                    double newQuantity = ingredient.Quantity * scale;
                    Console.WriteLine($"\n{newQuantity} {ingredient.Unit} of {ingredient.Name}");
                }
            }
            else
            {
                Console.WriteLine("Invalid scaling factor. Please enter a positive integer.");
            }
        }
        else if (!answer.Equals("no"))
        {
            Console.WriteLine("Invalid response. Please type 'yes' or 'no'.");
        }
    }
    public void Delete()
    {
        recipe = null;
        Console.WriteLine("\nRecipe deleted successfully.");
    }
}

