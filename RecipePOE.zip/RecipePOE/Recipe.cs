﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipePOE
{
  class Recipe
    {
        public string Name { get; set; }
        public Ingredient[] Ingredients { get; set; }
        public string[] Steps { get; set; }

        public Recipe(string name, int ingredientCount)
        {
            Name = name;
            Ingredients = new Ingredient[ingredientCount];
        }
    }
}

